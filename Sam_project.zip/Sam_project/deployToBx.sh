bx api https://api.ng.bluemix.net
bx login
bx target -o samli1996511@gmail.com -s COMPS381F
bx cf push 381MiniProj -m 64m
